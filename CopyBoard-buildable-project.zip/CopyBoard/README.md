# CopyBoard — Android keyboard with clipboard quick inserts

## Build the APK on a computer
1. Open this folder in Android Studio.
2. Let Gradle sync and install Android SDK 35 if prompted.
3. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Build without Android Studio using GitHub Actions
1. Create a GitHub account/repository and upload the contents of this project to the repository (keep the `.github/workflows/build-apk.yml` file).
2. Open the repository's **Actions** tab.
3. Run **Build CopyBoard APK** (or push to the `main` branch).
4. Open the completed workflow run and download the `CopyBoard-debug-apk` artifact.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

## Install and enable
1. Install `app-debug.apk` on your Android phone. If Android asks, allow installation from the app you used to open the file.
2. Open CopyBoard and tap **Включить CopyBoard**.
3. Enable CopyBoard in Android keyboard settings.
4. Return and tap **Выбрать CopyBoard клавиатурой**.
5. Open a text field, switch to the **Буфер** tab, and pin snippets with ☆. They appear as one-tap buttons above the normal keyboard.

## Prototype limitations
- Clipboard capture is attempted while the keyboard is visible and when it opens. Android restricts background clipboard access, so capture of every copy while the keyboard is closed cannot be guaranteed.
- History is stored locally, up to 100 items. This prototype does not sync.
- Do not use this prototype to store passwords or other secrets: clipboard history is not a secure password manager.
- This is an early prototype, not a production-ready keyboard. Test it before relying on it.
