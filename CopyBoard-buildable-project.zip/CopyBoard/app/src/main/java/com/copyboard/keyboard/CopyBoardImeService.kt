package com.copyboard.keyboard

import android.inputmethodservice.InputMethodService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

class CopyBoardImeService : InputMethodService() {
    private lateinit var clipboard: ClipboardManager
    private var root: LinearLayout? = null
    private var content: LinearLayout? = null
    private var clipboardTab = true
    private var russian = true
    private var shift = false
    private val history = mutableListOf<Entry>()
    private val prefs by lazy { getSharedPreferences("copyboard", Context.MODE_PRIVATE) }

    data class Entry(val text: String, var pinned: Boolean = false)

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        captureClipboard()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val bg = 0xFF101116.toInt()
    private val key = 0xFF292D37.toInt()
    private val accent = 0xFF7867F5.toInt()
    private val fg = 0xFFF4F5F7.toInt()
    private val muted = 0xFFAEB3C0.toInt()

    override fun onCreate() {
        super.onCreate()
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        loadHistory()
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(7), dp(6), dp(7))
            setBackgroundColor(bg)
        }
        render()
        return root!!
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        try {
            clipboard.addPrimaryClipChangedListener(clipListener)
            captureClipboard()
        } catch (_: Exception) { }
        render()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        try { clipboard.removePrimaryClipChangedListener(clipListener) } catch (_: Exception) { }
        super.onFinishInputView(finishingInput)
    }

    private fun captureClipboard() {
        try {
            if (!clipboard.hasPrimaryClip()) return
            val clip = clipboard.primaryClip ?: return
            if (clip.itemCount == 0) return
            val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: return
            if (text.isBlank()) return
            if (history.firstOrNull()?.text == text) return
            history.add(0, Entry(text))
            trimAndSave()
            render()
        } catch (_: SecurityException) {
            // Android may restrict clipboard access depending on OS version and app state.
        } catch (_: Exception) { }
    }

    private fun trimAndSave() {
        while (history.size > 100) {
            val lastUnpinned = history.indexOfLast { !it.pinned }
            if (lastUnpinned >= 0) history.removeAt(lastUnpinned) else break
        }
        saveHistory()
    }

    private fun loadHistory() {
        try {
            val arr = JSONArray(prefs.getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                history.add(Entry(o.optString("text"), o.optBoolean("pinned")))
            }
        } catch (_: Exception) { }
    }

    private fun saveHistory() {
        val arr = JSONArray()
        history.forEach {
            arr.put(JSONObject().put("text", it.text).put("pinned", it.pinned))
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    private fun button(label: String, onClick: () -> Unit, color: Int = key): Button {
        return Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            setTextColor(fg)
            background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = dp(9).toFloat()
            }
            setPadding(dp(3), 0, dp(3), 0)
            setOnClickListener { onClick() }
        }
    }

    private fun addRow(parent: LinearLayout, labels: List<String>, action: (String) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        labels.forEach { label ->
            row.addView(button(label, { action(label) }), LinearLayout.LayoutParams(0, dp(43), 1f).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            })
        }
        parent.addView(row)
    }

    private fun render() {
        val host = root ?: return
        host.removeAllViews()
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabs.addView(button("Буфер", { clipboardTab = true; render() }, if (clipboardTab) accent else key),
            LinearLayout.LayoutParams(0, dp(43), 1f))
        tabs.addView(button("Клавиатура", { clipboardTab = false; render() }, if (!clipboardTab) accent else key),
            LinearLayout.LayoutParams(0, dp(43), 1f))
        tabs.addView(button("⌄", { requestHideSelf(0) }, key), LinearLayout.LayoutParams(dp(48), dp(43)))
        host.addView(tabs)

        if (clipboardTab) renderClipboard(host) else renderKeys(host)
    }

    private fun renderClipboard(host: LinearLayout) {
        val heading = TextView(this).apply {
            text = "История буфера · ${history.size}/100"
            setTextColor(fg); textSize = 13f
            setPadding(dp(5), dp(8), dp(5), dp(6))
        }
        host.addView(heading)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (history.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Пока пусто. Скопируй текст, пока клавиатура открыта, или открой эту вкладку после копирования."
                setTextColor(muted); textSize = 13f; setPadding(dp(10), dp(18), dp(10), dp(18))
            })
        }
        history.forEachIndexed { index, entry ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(7), dp(4), dp(4), dp(4))
                background = GradientDrawable().apply { setColor(key); cornerRadius = dp(10).toFloat() }
            }
            val preview = TextView(this).apply {
                text = (if (entry.pinned) "★ " else "") + entry.text.replace("\n", " ")
                maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
                textSize = 13f; setTextColor(fg); gravity = android.view.Gravity.CENTER_VERTICAL
                setOnClickListener { currentInputConnection?.commitText(entry.text, 1) }
            }
            card.addView(preview, LinearLayout.LayoutParams(0, dp(54), 1f))
            card.addView(button("Вставить", { currentInputConnection?.commitText(entry.text, 1) }, accent),
                LinearLayout.LayoutParams(dp(76), dp(44)).apply { gravity = android.view.Gravity.CENTER_VERTICAL })
            card.addView(button(if (entry.pinned) "★" else "☆", {
                entry.pinned = !entry.pinned; saveHistory(); render()
            }), LinearLayout.LayoutParams(dp(42), dp(44)).apply { gravity = android.view.Gravity.CENTER_VERTICAL })
            card.addView(button("×", {
                history.removeAt(index); saveHistory(); render()
            }), LinearLayout.LayoutParams(dp(38), dp(44)).apply { gravity = android.view.Gravity.CENTER_VERTICAL })
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(5)
            })
        }
        scroll.addView(list)
        host.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        host.addView(button("Очистить историю (кроме избранного)", {
            history.removeAll { !it.pinned }; saveHistory(); render()
        }), LinearLayout.LayoutParams(-1, dp(40)))
    }

    private fun renderKeys(host: LinearLayout) {
        // Pinned clipboard snippets appear as one-tap insert buttons above the normal keys.
        val pinned = history.filter { it.pinned }
        val quickBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(2), 0, dp(5))
        }
        if (pinned.isEmpty()) {
            quickBar.addView(TextView(this).apply {
                text = "Закрепи тексты во вкладке «Буфер» — они появятся здесь"
                textSize = 11f
                setTextColor(muted)
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(6), 0, dp(6), 0)
            }, LinearLayout.LayoutParams(-1, dp(34)))
        } else {
            val quickScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(quickBar)
            }
            pinned.forEach { entry ->
                quickBar.addView(button(
                    entry.text.replace("\\n", " ").take(18),
                    { currentInputConnection?.commitText(entry.text, 1) },
                    accent
                ), LinearLayout.LayoutParams(-2, dp(36)).apply {
                    setMargins(dp(3), 0, dp(3), 0)
                })
            }
            host.addView(quickScroll, LinearLayout.LayoutParams(-1, dp(42)))
        }
        val rows = if (russian) listOf(
            listOf("й","ц","у","к","е","н","г","ш","щ","з","х"),
            listOf("ф","ы","в","а","п","р","о","л","д","ж","э"),
            listOf("⇧","я","ч","с","м","и","т","ь","б","ю","⌫")
        ) else listOf(
            listOf("q","w","e","r","t","y","u","i","o","p"),
            listOf("a","s","d","f","g","h","j","k","l"),
            listOf("⇧","z","x","c","v","b","n","m","⌫")
        )
        rows.forEach { row ->
            addRow(host, row) { keyLabel ->
                when (keyLabel) {
                    "⇧" -> { shift = !shift; render() }
                    "⌫" -> currentInputConnection?.deleteSurroundingText(1, 0)
                    else -> currentInputConnection?.commitText(if (shift) keyLabel.uppercase() else keyLabel, 1)
                }
            }
        }
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(button("?123", { currentInputConnection?.commitText("123", 1) }), LinearLayout.LayoutParams(dp(58), dp(44)))
        bottom.addView(button(if (russian) "RU" else "EN", { russian = !russian; render() }), LinearLayout.LayoutParams(dp(48), dp(44)))
        bottom.addView(button(",", { currentInputConnection?.commitText(",", 1) }), LinearLayout.LayoutParams(dp(40), dp(44)))
        bottom.addView(button("Пробел", { currentInputConnection?.commitText(" ", 1) }), LinearLayout.LayoutParams(0, dp(44), 1f))
        bottom.addView(button(".", { currentInputConnection?.commitText(".", 1) }), LinearLayout.LayoutParams(dp(40), dp(44)))
        bottom.addView(button("↵", { currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER)) }, accent), LinearLayout.LayoutParams(dp(48), dp(44)))
        host.addView(bottom)
    }
}
