package com.copyboard.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = 0xFF101116.toInt()
        val panel = 0xFF20232B.toInt()
        val white = 0xFFF4F5F7.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "CopyBoard"
            textSize = 30f
            setTextColor(white)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Твоя клавиатура с историей буфера обмена"
            textSize = 16f
            setTextColor(0xFFB8BBC5.toInt())
            setPadding(0, dp(8), 0, dp(28))
        })
        fun actionButton(label: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                isAllCaps = false
                setTextColor(white)
                setBackgroundColor(panel)
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(12) })
        }
        actionButton("1. Включить CopyBoard") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        actionButton("2. Выбрать CopyBoard клавиатурой") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        root.addView(TextView(this).apply {
            text = "Как начать:\n\n1) Включи CopyBoard в списке клавиатур.\n2) Выбери CopyBoard как текущую клавиатуру.\n3) Открой любое поле ввода и перейди на вкладку «Буфер».\n4) Скопированный текст будет появляться в истории, когда клавиатура активна и Android разрешает чтение буфера.\n\nИстория хранится локально на устройстве."
            textSize = 15f
            setTextColor(white)
            setPadding(0, dp(16), 0, 0)
        })
        setContentView(root)
    }
}
